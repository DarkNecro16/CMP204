<?php
// database details
$servername = "lochnagar.abertay.ac.uk";
$dbusername = "sql2103490";
$dbpassword = "earned record gravity counted";
$dbname = "sql2103490";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);


if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
}
?>
