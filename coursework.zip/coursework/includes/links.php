<?php

session_start();

echo '<ul>';

// links always on show 
echo '<li><a href="index.php">Home</a></li>';
echo '<li><a href="upcomingEvents.php">Upcoming Events</a></li>';
echo '<li><a href="teamMembers.php">Team Members</a></li>';
echo '<li><a href="req.php">Requirements</a></li>';

// Chec to se eif user is signed in 
if (!isset($_SESSION['username'])) 
{
    // links to be shown if user is not signed in 
    echo '<li><a href="register.php">Register</a></li>';
    echo '<li><a href="login.php">Login</a></li>';
} else 
{
    // links to be shown if user is signed in 
    echo '<li><a href="userProfile.php">User Profile</a></li>';
    echo '<li><a href="logout.php">Logout</a></li>';
}

echo '</ul>';
?>


