
<!--footer information GDPR 1-5 info -->
<footer class="footer" style="padding-top: 100px;">
    <div class="footer-container">
        <div class="footer-info" style="font-size: 12px;">
            Upon signing up to this website, users' personal information may be stored, such as name and email address. Due to the nature of the website details of events you may attend will be held also. We collect personal information to provide users with access to our website's features and
            services. This information is also used to help improve services provided to you. User data will be processed securely and used solely for the purposes of access to our services
            and features. We implement encryption and access controls to protect user data. User data will be retained for the duration of the user's account activity. Users can request data
            deletion, and inactive accounts will be deleted after a specified period. Users can contact our support team at 2103490@uad.ac.uk to request data removal or access to
            their stored information. Please note that continuing to register will be deemed as acceptance to these conditions. 2023 3rd Ranger Battalion Fictitious Esports. All Rights Reserved &copy;
        </div>
    </div>
</footer>
