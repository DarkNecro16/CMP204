<?php

session_start();
include_once "includes/connectionString.php";

// check if the user is logged in
if (!isset($_SESSION["username"]) || !isset($_SESSION["user_id"])) 
{
    //if the user is not found in the session, logout and redirect to the login page
    session_destroy();
    header("Location: login.php");
    exit();
}

// fetch user details from DB
$username = $_SESSION["username"];
$selectUserSQL = "SELECT * FROM users WHERE username = ?";
$stmt = $conn->prepare($selectUserSQL);
$stmt->bind_param("s", $username);
$stmt->execute();
$resultUser = $stmt->get_result();

if ($resultUser->num_rows > 0) 
{
    $userData = $resultUser->fetch_assoc();
} else 
{
    // If the user is not found, logout and redirect to the login page
    session_destroy();
    header("Location: login.php");
    exit();
}

// Fetch attended events with attendance status for the current user
$attendedEvents = array();
$selectAttendedEventsSQL = "SELECT * FROM attended_events WHERE user_id = " . $_SESSION['user_id'];
$resultAttendedEvents = $conn->query($selectAttendedEventsSQL);

if ($resultAttendedEvents) 
{
    if ($resultAttendedEvents->num_rows > 0)
     {
        while ($row = $resultAttendedEvents->fetch_assoc()) 
        {
            $attendedEvents[] = array(
                'event_name' => $row['event_name'],
                'attendance_status' => $row['attendance_status']
            );
        }
    } 
}

$stmt->close();

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>User Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="javascript/script.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-lg topnav">
    <div class="container-fluid">
        <?php include_once "includes/links.php" ?>
    </div>
</nav>


<div class="container mt-5">
    <h1 class="text-center">Welcome, <?php echo $_SESSION["username"]; ?>!</h1>

    <div class="mt-5">
        <h2>User Details</h2>
        <table class="custom-table mx-auto">
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Surname</th>
                    <th>Email</th>
                    <th>Username</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo $userData["first_name"]; ?></td>
                    <td><?php echo $userData["surname"]; ?></td>
                    <td><?php echo $userData["email"]; ?></td>
                    <td><?php echo $userData["username"]; ?></td>
                </tr>
            </tbody>
        </table>
    </div>

  

    <div class="mt-5">
    <h2>Attending Events</h2>

    <!-- add event -->
<form id="addEventForm" onsubmit="submitEventForm(event)" class="mb-3">
    <label for="newEventName">Event Name:</label>
    <input type="text" id="newEventName" name="eventName" required>
    <input type="hidden" name="context" value="userProfile">
    <button type="submit" class="btn btn-events">Add Event</button>
</form>

    <table class="custom-table mx-auto">
        <thead>
            <tr>
                <th>Event Name</th>
                <th>Attendance Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>

            <?php
            //display all events in a table 
            foreach ($attendedEvents as $event) {
                echo "<tr>";
                echo "<td>{$event['event_name']}</td>";
                echo "<td>{$event['attendance_status']}</td>";
                echo "<td>";
                echo "<div class='d-flex'>";
                echo "<form action='editEventsAttended.php' method='post' class='mr-2'>";
                echo "<input type='hidden' name='eventToUpdate' value='{$event['event_name']}'>";
                echo "<label for='attendanceStatus'>Update Status:</label>";
                echo "<select name='attendanceStatus' id='attendanceStatus'>";
                echo "<option value='yes' " . ($event['attendance_status'] == 'yes' ? 'selected' : '') . ">Yes</option>";
                echo "<option value='no' " . ($event['attendance_status'] == 'no' ? 'selected' : '') . ">No</option>";
                echo "</select>";
                echo "<button type='submit' class=' btn-events'>Update</button>";
                echo "</form>";
                echo "<form action='deleteEventsAttended.php' method='post'>";
                echo "<input type='hidden' name='eventToDelete' value='{$event['event_name']}'>";
                echo "<button type='submit' class=' btn-events'>Delete</button>";
                echo "</form>";
                echo "</div>";
                echo "</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
</div>

    <!-- Latest compiled Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
<?php include 'includes/footer.php'; ?>
</html>

