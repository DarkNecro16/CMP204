<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Welcome To 3RD Ranger Battalion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="javascript/script.js"></script>
</head>

<body>


            <nav class="navbar navbar-expand-lg topnav">
                <div class="container-fluid">
                    <?php include_once "includes/links.php" ?>
                </div>
            </nav>


            <div class="container mt-5">
                <div class="row justify-content-center">
                    <div class="col-md-4">
                        <div class="logo-container">
                            <img src="images/clanlogo.png" alt="3RD RANGER BATTALION">
                        </div>
                    </div>
                </div>
            </div>


            <div class="container mt-5 history-section">
    <h3 class="text-left mb-4">History</h3>

    <div class="row">
        <div class="col-md-6 order-md-1 order-2">
            <p class="history-text text-white">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32. The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham</p>
        </div>

        <div class="col-md-4 order-md-5 order-1">
            <p class="history-text text-white">Quisque ornare risus ipsum. Suspendisse efficitur condimentum sem nec ultricies. Aenean imperdiet felis et odio tempor consequat. Donec facilisis, ex ac accumsan euismod, risus felis fringilla sem, eget eleifend nunc quam ac justo. In elementum, urna a varius mollis, diam nibh tempus magna, nec pulvinar ipsum ex nec orci. Duis nec pretium augue, vel tempor massa. Vivamus sit amet congue lacus. Nulla maximus tellus in dolor accumsan semper eget eget sapien. Fusce varius feugiat sapien, a gravida felis suscipit a.</p>
        </div>
    </div>
</div>




<!-- button to trigger the animation -->
<div class="text-center mt-3">
    <button id="showMatchesBtn" class=" btn-events btn-lg fs-5">CLICK HERE FOR RECENT CHAMPIONSHIP MATCHES</button>
</div>

  <!-- game review section -->
  <div class="row mt-5 justify-content-center glass-box" style="display: none;">
    <div class="col-md-14 text-center">
        <h2>RECENT CHAMPIONSHIP MATCHES</h2>
    </div>

    <!-- video 1 -->
    <div class="col-md-3">
        <div class="card event-card">
            <iframe width="100%" height="200"
                    src="https://www.youtube.com/embed/QnIhWGUhvaE?si=F3YJBvt200x8W9J7"
                    title="YouTube video player" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowfullscreen></iframe>
            <div class="card-body">
                <h3 class="text-center mb-1">NY Sublimers Vs Atlanta Faze</h3>
                <p class="text-center">An action packed finale from AF and NYS.</p>
            </div>
        </div>
    </div>
    <!-- video 2 -->
    <div class="col-md-3">
        <div class="card event-card">
            <iframe width="100%" height="200"
                    src="https://www.youtube.com/embed/wQZkBXpPA0o?si=ODFuDekD4q-bdD2i"
                    title="YouTube video player" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowfullscreen></iframe>
            <div class="card-body">
                <h3 class="text-center mb-1">Optic Texas Vs Atlanta Faze </h3>
                <p class="text-center">Words cant describe what happened at the end of this!!!!!.</p>
            </div>
        </div>
    </div>
    <!-- video 3 -->
    <div class="col-md-3">
        <div class="card event-card">
            <iframe width="100%" height="200"
                    src="https://www.youtube.com/embed/6v5LoB-bjHI?si=LjWdpFoz9hpCfTFw"
                    title="YouTube video player" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowfullscreen></iframe>
            <div class="card-body">
                <h3 class="text-center mb-1">LA thieves Vs Seattle Surge</h3>
                <p class="text-center">OMG!! that quickscope in MID AIR!! .</p>
            </div>
        </div>
    </div>
    <!-- video 4 -->
    <div class="col-md-3">
        <div class="card event-card">
            <iframe width="100%" height="200"
                    src="https://www.youtube.com/embed/npHv3ks7Zvo?si=dkA2_HGHAiJtybMs"
                    title="YouTube video player" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowfullscreen></iframe>
            <div class="card-body">
                <h3 class="text-center mb-1">NYSublimers Vs TorontoUltra</h3>
                <p class="text-center">Carnage in toronto!! a sublime finish from the NY champions!.</p>
            </div>
        </div>
    </div>
</div>

<!-- button to trigger AJAX request -->
<div class="text-center mt-3">
    <button id="displayStandingsBtn" class="btn-events btn-lg fs-5">DISPLAY CURRENT LEAGUE STANDINGS</button>
</div>

<!-- Container to display league standings -->
<div id="leagueStandings" class="mt-3"></div>






<!-- Latest compiled Bootstrap JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>


</body>

<?php include 'includes/footer.php'; ?>
</html>
