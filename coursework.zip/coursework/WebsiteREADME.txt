welcome to my website please note the test account is as followed 

Account Name: Testaccount123
Account Password: Testaccount123@

please note these credentials are case sensitive 


functionality is as followed 

index

2 seperrate buttons 

one displays recent championship matches when clicked and the other displays current league standings. when the league standings is hovered over it changes colour dynamically
as does the history box when hovered over, this is to allow for better readibility 



upcomingEvents

Has 3 events listed with times and dates. The countdown timer is counting down to the "next" event. IF a user is logged in they may attend events from this page.
if a user is NOT logged in and they click the attend event button an alert will display prompting that the user must be logged in andredirect to the login page

there is a button on this page also "Load Event Results" which pulls in results from a file and displays them here without page needing to be reloaded.

Team Members

3 team members are displayed here. if " click for player stats" is clicked then it will dynamically bring in the players stats from a seperate file on the server and load it into HTML format inside the dropdown card 


Requirments

displays all requirments have been met and how i achieved them 



Register

**IMPORTANT INFORMATION**

i have some increased validation checks with registration to make passwords more secure and to also ensure that users are using approprite input types depending on the req

first name and last name MUST contain only alphabetic chars A-Z,a-z

Usernames have no restrictions

Emails MUST be valid email format (example@example_email.com)

Passwords MUST contain at least ONE uppercase, at least ONE special character and be a minimum of 10 chars in length. these requirments are displayed to the user via box when password box is clicked

passwords MUST also match 

ANY illegal input boxes will REMAIN RED until the input requirments are met. for FIRST and LAST names aswell as EMAIL if you hover over the box it has the specifications for input listed

once ALL validation boxes are legal the RED border will dissapear promting VALIDATION. this is important as the checks done on the back end processing pages are performing these checks.

PLEASE NOTE - GDPR information pop up also appears on this page aswell as a footer on every other page. a user can accept or deny with a coresponnding alert for each. if the user ACCEPTS they continue with registration. if they DENY they may continue with registration but the alert stipulates that " they agree to the terms if they proceed to register " 

Login

user can log in here using registered username and password.


userProfile

This page displays users details in a table.
also displays current events attending ( if any)
from here a user can add any event to attend
they can update there attendance status from "yes" to "no" and vice versa
and they can also delete and event attended 

any events attended from the upcomingEvents page will be listed here also
if an event is already being attended an alert will pop.


please also note that if a user is logged in the registration and login pages dissapear 
and if a user is not logged in then the logout and userprofile pages disapear 



Thank you for taking your time to view my Website i have enjoyed creating it and hope you enjoy broswing =)

David Dandie - 2103490



