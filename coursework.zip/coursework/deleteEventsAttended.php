<?php
session_start();
include_once "includes/connectionString.php";


//deletes an event from the attended_events table, also uses prepared statements and redirects back to userProfile on deletion

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    $eventToDelete = $_POST["eventToDelete"];

    // ts is a SQL query to delete from attended_events using prepared statements 
    $deleteSQL = "DELETE FROM attended_events WHERE event_name = ?";
    $delete = $conn->prepare($deleteSQL);
    $delete->bind_param("s", $eventToDelete);

   // once event is deleted redirect back to user profile page 
    if ($delete->execute()) 
    
    {
   
        header("Location: userProfile.php");
        exit();
    } 

    $delete->close();
}


$conn->close();
?>

