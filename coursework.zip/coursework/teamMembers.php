<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>CMP204 Unit Two Coursework Template</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="javascript/script.js"></script>
</head>

<body class="team-members">

<nav class="navbar navbar-expand-lg topnav">
    <div class="container-fluid">
        <?php include_once "includes/links.php" ?>
    </div>
</nav>


<h1>Meet 3RD Ranger Battalion</h1>

<div class="container_team">
    <div class="row">

        <!-- Infamous card -->
        <div class="col-md-4">
            <div class="card event-card team-member-card h-100">
                <img src="./images/teammember1.jpg" class="card-img-top" alt="Team Member 1">
                <div class="card-body">
                    <h5 class="event-title">InfamousNecro</h5>
                    <p class="event-text">Team Leader</p>
                    <button class="btn btn-events" data-bs-toggle="collapse" data-bs-target="#game-info1" aria-expanded="false" aria-controls="game-info1">Click for Player Stats</button>
                    <div class="collapse" id="game-info1">
                        <div class="card event-card" id="stats1"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- CabbageMan card -->
        <div class="col-md-4">
            <div class="card event-card team-member-card h-100">
                <img src="./images/teammember2.jpg" class="card-img-top" alt="Team Member 2">
                <div class="card-body">
                    <h5 class="event-title">CabbageMan</h5>
                    <p class="event-text">MVP</p>
                    <button class="btn btn-events" data-bs-toggle="collapse" data-bs-target="#game-info2" aria-expanded="false" aria-controls="game-info2">Click for Player Stats</button>
                    <div class="collapse" id="game-info2">
                        <div class="card event-card" id="stats2"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Biggys card -->
        <div class="col-md-4">
            <div class="card event-card team-member-card h-100">
                <img src="./images/teammember3.jpg" class="card-img-top" alt="Team Member 3">
                <div class="card-body">
                    <h5 class="event-title">BiggySnails</h5>
                    <p class="event-text">Quickscoper</p>
                    <button class="btn btn-events" data-bs-toggle="collapse" data-bs-target="#game-info3" aria-expanded="false" aria-controls="game-info3">Click for Player Stats</button>
                    <div class="collapse" id="game-info3">
                        <div class="card event-card" id="stats3"></div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>




<!-- Latest compiled Bootstrap JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
<?php include 'includes/footer.php'; ?>
</body>
</html>
