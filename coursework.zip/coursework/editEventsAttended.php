<?php
session_start();
include_once "includes/connectionString.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") 

//input sanatisation
//edits the user_id "users" attended_events  ts is performed using prepared statements 
// updates attended status from yes or no
//redirects user back to user profile 
{
    $eventName = htmlspecialchars($_POST["eventToUpdate"]);
    $attendanceStatus = htmlspecialchars($_POST["attendanceStatus"]);
    
   
    $userId = $_SESSION["user_id"]; 

    $updateSQL = "UPDATE attended_events SET attendance_status = ? WHERE event_name = ? AND user_id = ?";
    $update = $conn->prepare($updateSQL);
    $update->bind_param("sss", $attendanceStatus, $eventName, $userId);

    if ($update->execute()) {
       
        header("Location: userProfile.php?updateSuccess=true");
        exit();
    } else {
        
        header("Location: userProfile.php?updateError=" . urlencode($update->error));
        exit();
    }

    $update->close();
}

$conn->close();
?>
