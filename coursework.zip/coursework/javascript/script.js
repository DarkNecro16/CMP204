//***********************JAVA SCRIPT MANIPULATION**************************** */

//function changes size of text on mouseover and gives background shadow colour change
// based on a listenting event 
document.addEventListener("DOMContentLoaded", function () 
{
    var navlinks = document.querySelectorAll(".topnav li a");

    navlinks.forEach(function (link) 
    {
        link.addEventListener("mouseover", function () 
        {
           
            link.style.fontsize = "110%";
            link.style.textshadow = "0 0 10px #ffffff, 0 0 20px #ffffff, 0 0 30px #ffffff";
        });

        link.addEventListener("mouseout", function () 
        {
         
            link.style.fontsize = "90%";
            link.style.textshadow = "none";
        });
    });
});
/********************************************************************** */

//********************hide matches button *************************** */


//function drops down the glass box that the recent championship matches are held in 
$(document).ready(function () 
{
    $("#showMatchesBtn").click(function () 
    {
        console.log("Button clicked");
        $(".glass-box").slideToggle();
    });
});

//******************************************************************* */

//********************USE OF AJAX WITHOUT A LIBRARY REQ 5 ******************** */

// adds a listener to btn-events and retrieves value set by dat-bs-target 
document.addEventListener("DOMContentLoaded", function () 
{
    var buttons = document.querySelectorAll('.btn-events');

    buttons.forEach(function (button) 
    {
        button.addEventListener('click', function () 
        {
            var targetId = this.getAttribute('data-bs-target');
            loadDoc(targetId);
        });
    });
});

// loaddoc responisible for the XMLhttp request t playerstats if connection is good 
// then it will call the updateGameinfo function
function loadDoc(targetId) 
{
    var xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function () 
    {
        if (xhr.readyState == 4 && xhr.status == 200) 
        {
            updateGameInfo(targetId, JSON.parse(xhr.responseText));
        } else if (xhr.readyState == 4) 
        {
            console.error('Error', xhr.status);
        }
    };

    xhr.open('GET', 'playerStats.txt', true);
    xhr.send();
}

//takes the targetId & array of playerinfo xtracts the playerinfo from targetid
// and updates HTML content it target element
function updateGameInfo(targetId, playerInfoArray) 
{
    var targetelement = document.querySelector(targetId + ' .event-card');
    var player_index = targetId.charAt(targetId.length - 1) - 1;

    var player_info = playerInfoArray[player_index];

    if (player_info && player_info.stats) 
    {
        var gameInfoHtml = `
            <div class="container mt-5">
                <table class="custom-table">
                    <tbody>
                        <tr>
                            <th scope="row">Name</th>
                            <td>${player_info.name}</td>
                        </tr>
                        <tr>
                            <th scope="row">Role</th>
                            <td>${player_info.role}</td>
                        </tr>
                        <tr>
                            <th scope="row">Skills</th>
                            <td>${player_info.skills}</td>
                        </tr>
                        <tr>
                            <th scope="row">Level</th>
                            <td>${player_info.level}</td>
                        </tr>
                        <tr>
                            <th scope="row">Wins</th>
                            <td>${player_info.stats.Wins}</td>
                        </tr>
                        <tr>
                            <th scope="row">Losses</th>
                            <td>${player_info.stats.Losses}</td>
                        </tr>
                        <tr>
                            <th scope="row">Quote</th>
                            <td>${player_info.quote}</td>
                        </tr>
                    </tbody>
                </table>
            </div> `;

        targetelement.innerHTML = gameInfoHtml;
    } else
     {
        console.error('Invalid player information:', player_info);
    }
}
//************************************************************************ */

//************************LEAGUE STANDINGS AJAX************************ */

$(document).ready(function () 
{
   // display or hide league standings
    function toggleLeagueStandings() 
    {
        var xmlFile = 'LeagueStandings.xml';

        // check if the table is visible
        if ($('#leagueStandings').is(':visible')) 
        {
            // if visible, hide the table and change button text to show
            $('#leagueStandings').hide();
            $('#displayStandingsBtn').text('DISPLAY CURRENT LEAGUE STANDINGS');
        } else
         {
            // if hidden display the table and change button text to hide
            $.ajax(
                {
                type: 'GET',
                url: xmlFile,
                dataType: 'xml',
                success: function (xml) 
                {
                    // clear the existing content
                    $('#leagueStandings').empty();

                    // Add the table structure
                    var standingsHtml = `
                        <div class="container mt-5">
                            <table class="custom-table">
                                <thead>
                                    <tr>
                                        <th scope="col">Team</th>
                                        <th scope="col">Wins</th>
                                        <th scope="col">Losses</th>
                                        <th scope="col">Points</th>
                                    </tr>
                                </thead>
                                <tbody>`;

                    // loop through XML data to extract team information and append rows
                    $(xml).find('team').each(function () 
                    {
                        var teamName = $(this).find('name').text();
                        var wins = parseInt($(this).find('wins').text());
                        var losses = parseInt($(this).find('losses').text());
                        var points = wins * 3;

                        // add each row individually
                        standingsHtml += `
                            <tr>
                                <td>${teamName}</td>
                                <td>${wins}</td>
                                <td>${losses}</td>
                                <td>${points}</td>
                            </tr>`;
                    });

                    //shut table
                    standingsHtml += `
                                </tbody>
                            </table>
                        </div>`;

                    // display the  standings in the designated container
                    $('#leagueStandings').html(standingsHtml).show();
                    $('#displayStandingsBtn').text('HIDE CURRENT LEAGUE STANDINGS');
                },
                error: function () 
                {
                    //error handling
                    alert('Error loading league standings.');
                },
            });
        }
    }

    // event listener for the button click
    $('#displayStandingsBtn').click(function () 
    {
       
        toggleLeagueStandings();
    });
});





/********************************************************************** */

//****************CLOCK FOR REQ 4 USE JQUERY ************************** */
$(document).ready(function () 
//set up event date 
{
    var eventDates = [
        new Date("Dec 30, 2023 18:00:00").getTime(),
        new Date("Jan 01, 2024 13:00:00").getTime(),
        new Date("Jan 08, 2024 15:00:00").getTime(),
        new Date("Feb 13, 2024 18:00:00").getTime()
    ];

    //updates ever second
    setInterval(updateCountdown, 1000);


    function updateCountdown() 
    {
        //current time
        var now = new Date().getTime();
        //store index of nearest event
        var nearestevent = -1;
        var nearestTimeDiff = Infinity;

        //loop through event dates 
        for (var i = 0; i < eventDates.length; i++) 
        {

            //calculate time diff between evvents and time now
            var timeDifference = eventDates[i] - now;

            //checks current date is in future ad if current event is closest 
            if (timeDifference > 0 && timeDifference < nearestTimeDiff)
            
            {
                nearestevent = i;
                nearestTimeDiff = timeDifference;
            }
        }

        //time calculations 
        if (nearestevent !== -1) 
        {
            var days = Math.floor(nearestTimeDiff / (1000 * 60 * 60 * 24));
            var hours = Math.floor((nearestTimeDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((nearestTimeDiff % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((nearestTimeDiff % (1000 * 60)) / 1000);

            $('#days').text(days + ' days');
            $('#hours').text(hours + ' hours');
            $('#minutes').text(minutes + ' minutes');
            $('#seconds').text(seconds + ' seconds');
        }
    }
});

//********************************************************************************* */




//****************************REQ 6 AJAX JQUERY FUNCTION FOR EVENT POSTING ***************************/
function attendEvent(eventName) 
{
    if (isLoggedIn) 
    {
        // user is logged in add event
        $.ajax
        ({
            type: "POST",
            url: "addEventsAttended.php",
            data: 
            {
                eventName: eventName,
            },
            dataType: "json",
            success: function (response) 
            {
                if (response.status === 'success') 
                {
                    // ivent attendance successful,response handling 
                    alert(response.message);

                
                    if (response.redirect) 
                    {
                        window.location.href = response.redirect;
                    }
                } else 
                {
                    // event attendance failed
                    alert(response.message);
                }
            }
        });
    } else 
    {
       //if no user logged in 
        alert("Users must be logged in to attend events.");
        window.location.href = "login.php";
    }
}



function submitEventForm(event) 
{
    
    event.preventDefault();

    // get form data
    var formData = $('#addEventForm').serialize();

    // send an AJAX request to the server to attend the event
    $.ajax(
        {
        type: "POST",
        url: "addEventsAttended.php",
        data: formData,
        dataType: 'json',

        success: function(response) 
        {
            // Handles the response processing 
            if (response.status === 'success') 
            {
                alert(response.message);

               
                if (response.redirect)
                 {
                    window.location.href = response.redirect;
                }
            } else 
            {
                alert(response.message);
            }
        },
    });
}

//******************FORM VALIDATION*************************************************** */

// this is for form validation to ensure that first name and last names contain only characters and if not display error messages
// also checks to make sure passwords match upon registration if not display error messages. corresponding proceesing pages complete back end checks also
function validateForm() 
{
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("surname").value;
    var password = document.getElementById("registerpassword").value;
    var confirmPassword = document.getElementById("confirmPassword").value;

 
    if (!/^[A-Za-z]+$/.test(firstName)) 
    {
        alert("Last name must contain only letters unless you are an anddroid in which case message us, thats pretty cool.");
        return false;
    }

    if (!/^[A-Za-z]+$/.test(lastName))
     {
        alert("Last name must contain only letters unless you are an anddroid in which case message us, thats pretty cool.");
        return false;
    }

    if (password !== confirmPassword) 
    {
        alert("passwords do not match bro,try again.");
        return false;
    }

    return true;
}




//****************GDPR POP UP****************************************************************************** */


// for handling the GDPR pop up on reg page please note the deny action cearly states continuance accepts these terms by default 
$(document).ready(function () 
{
    $('#gdprModal').modal('show');
});

function denyAction() 
{
   
    alert('You have denied the privacy policy but please note continuing to register would be an acceptance of our terms. Please continue with registration.');
   
    $('#gdprModal').modal('hide');
}

function acceptAction() 
{
 
    alert('You have accepted the privacy policy. Continue with registration.');
   
    $('#gdprModal').modal('hide');
}


$('#gdprModal').on('hide.bs.modal', function (event) 
{
    event.preventDefault();
});

//******************ASSWORD INFORMATION BOX***************************************************************************** */


//displays password conditions upon cicking on password input box 
function showPasswordInfo() 
{
    var passwordInfoBox = document.getElementById("passwordInfo");
    passwordInfoBox.style.display = "block";
}

//hides it 
function hidePasswordInfo() 
{
    var passwordInfoBox = document.getElementById("passwordInfo");
    passwordInfoBox.style.display = "none";
}

//***********************EVENT-RESULTS FUNCTION*************************************************************************/



// load content using AJAX
function loadContent(url, callback) 
{
    var xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function () 
    {
        if (xhr.readyState == 4 && xhr.status == 200) 
        {
            // if successful execute the callback with the response
            callback(xhr.responseText);
        }
    };

    xhr.open("GET", url, true);
    xhr.send();
}

//  toggle visibility and update button text
function toggleEventsResult() 
{
    var resultBox = document.querySelector('.advanced-event-result-box .card-body');
    var button = document.getElementById('loadEventsResultBtn');

    // check if the result box is visible
    var isVisible = resultBox.style.display !== 'none';

    if (isVisible) 
    {
        // ff visaible hide the result box and update button text
        resultBox.style.display = 'none';
        button.innerText = 'LOAD EVENTS RESULT';
    } else 
    {
        // otherwise show content and update buttn content
        loadContent("events-results.txt", function (response) 
        {
            // update content of the events result box with the loaded data
            resultBox.innerHTML = response;
            resultBox.style.display = 'block';

            // update button text to indicate hiding results
            button.innerText = 'HIDE RESULTS';
        });
    }
}

    // Event listener for button
    $(document).ready(function () {
        $("#loadEventsResultBtn").click(function () {
            toggleEventsResult();
        });
    });



