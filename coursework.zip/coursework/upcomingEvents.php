<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Upcoming Events</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="javascript/script.js"></script>


 <!-- i needed to put this block of code in as there are add event buttons attached and the user needs to be logged in to add these events
     otherwsise it diverts the user to the login screen. upon which the user can then go back to this page to add the event -->
    <?php
   
    session_start();

    $isLoggedIn = isset($_SESSION['user_id']) ? 'true' : 'false';
    ?>

    <script>
       
        var isLoggedIn = <?php echo $isLoggedIn; ?>;
    </script>
    
    
</head>


<body>

<nav class="navbar navbar-expand-lg topnav">
    <div class="container-fluid">
        <?php include_once "includes/links.php" ?>
    </div>
</nav>



<h1 class="text-center mt-3">Upcoming Events</h1>

<div id="cyberpunk-clock" class="container p-4 text-center">
    <h5 class="new-card-title">Time Until Next Event</h5>
    <table class="table table-borderless custom-table-clock mx-auto">
        <tr>
            <td id="days"></td>
            <td id="hours"></td>
            <td id="minutes"></td>
            <td id="seconds"></td>
        </tr>
    </table>
</div>

<div class="container mt-5 event-container">
    <div class="row justify-content-center">

        <!--event1-->
        <div class="col-md-4">
            <div class="card event-card">
                <img src="images/event1.png" class="card-img-top" alt="CallBreak in Tokyo">
                <div class="card-body event1-body d-flex flex-column">
                    <h5 class="event-title mb-2">CallBreak in Tokyo</h5>
                    <p class="event-text mb-1">Join us for an exciting CallBreak tournament in the vibrant city of Tokyo!</p>
                    <p class="event-time-date mb-2">Date: December 30th, 2023</p>
                    <p class="event-time-date">Time: 18:00</p>
                    <div id="countdownCallBreak" class="mb-2"></div>
                    <button class="btn btn-events align-self-center" onclick="attendEvent('CallBreak')">Attend Event</button>
                </div>
            </div>
        </div>

      <!--event2-->
        <div class="col-md-4">
            <div class="card event-card">
                <img src="images/event2.png" class="card-img-top" alt="ModernWarfare in London">
                <div class="card-body event2-body d-flex flex-column">
                    <h5 class="event-title mb-2">ModernWarfare in London</h5>
                    <p class="event-text mb-2">Experience intense battles in the heart of London with our ModernWarfare event!</p>
                    <p class="event-time-date mb-2">Date: January 1, 2024</p>
                    <p class="event-time-date">Time: 13:00</p>
                    <div id="countdownModernWarfare" class="mb-2"></div>
                    <button class="btn btn-events align-self-center" onclick="attendEvent('ModernWarfare in London')">Attend Event</button>
                </div>
            </div>
        </div>

      <!--event3-->
        <div class="col-md-4">
            <div class="card event-card">
                <img src="images/event3.png" class="card-img-top" alt="Eye4anEye in Sydney">
                <div class="card-body event3-body d-flex flex-column">
                    <h5 class="event-title mb-2">Eye4anEye in Sydney</h5>
                    <p class="event-text mb-2">Seek revenge in Eye4anEye event set against the beautiful backdrop of Sydney!</p>
                    <p class="event-time-date mb-2">Date: January 8th, 2024</p>
                    <p class="event-time-date">Time: 15:00</p>
                    <div id="countdownEye4anEye" class="mb-2"></div>
                    <button class="btn btn-events align-self-center" onclick="attendEvent('Eye4anEye')">Attend Event</button>
                </div>
            </div>
        </div>



    </div>
</div>


<!-- events result box -->
<div class="row justify-content-center mt-5">
    <div class="col-md-8">
        <div class="card advanced-event-result-box cyberpunk-result-box">
            <div class="card-body" style= "display: none;">
            
            </div>
        </div>
    </div>
</div>

<!-- button to trigger the loading or hiding of events result -->
<div class="text-center mt-3">
    <button id="loadEventsResultBtn" class="btn-events btn-lg fs-5">LOAD EVENTS RESULT</button>
</div>

            
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
<?php include 'includes/footer.php'; ?>
</html>

