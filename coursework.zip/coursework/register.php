<!doctype html>

<html lang="en">
<head>
	<meta charset="utf-8">
	<title>CMP204 Unit Two Coursework Template</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="javascript/script.js"></script>
</head>

<body class="register d-flex flex-column min-vh-100">
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <div class="topnav">
                <?php include_once "includes/links.php" ?>
            </div>
        </div>
    </nav>

      <!-- Reg form -->
      <h1 class="text-center">Register</h1>
    <div class="container mt-5 mb-5 d-flex flex-grow-1 justify-content-center align-items-center register-container">
        <form method="POST" action="processRegistration.php" onsubmit="return validateForm()">


        <div class="mb-3">
                <label for="firstName" class="form-label regform-label">First Name</label>
                <input type="text" class="form-control regform" id="firstName" name="firstName" pattern="[A-Za-z]+" title=" Only Alphabetical Characters (A-Z,a-z) are allowed for First name "required>
            </div>

            <div class="mb-3">
                <label for="surname" class="form-label regform-label">Last Name</label>
                <input type="text" class="form-control regform" id="surname" name="surname" pattern="[A-Za-z]+"title=" Only Alphabetical Characters (A-Z,a-z) are allowed for Last name " required>
            </div>

            <div class="mb-3">
                <label for="username" class="form-label regform-label">Username</label>
                <input type="text" class="form-control regform" id="username" name="username" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label regform-label">Email</label>
                <input type="email" class="form-control regform" id="email" name="email"title=" Email must be valid (example@example_email.com) " required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label regform-label">Password</label>
                <input type="password" class="form-control regform" id="registerpassword" name="password" required onfocus="showPasswordInfo()" onblur="hidePasswordInfo()">
                
           
                <div class="speech-bubble" id="passwordInfo">
                    <div class="speech-bubble-content">
                        Password must:
                        <ul>
                            <li>Be at least 10 characters long</li>
                            <li>Contain at least one uppercase letter</li>
                            <li>Contain at least one special character</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="mb-3">
                <label for="confirmPassword" class="form-label regform-label">Confirm Password</label>
                <input type="password" class="form-control regform" id="confirmPassword" name="confirmPassword" required>
            </div>

              <button type="submit" class="btn btn-events">Register</button>
        </form>
    </div>


 <!-- Mmdal for GDPR --> 
<div class="modal fade" id="gdprModal" tabindex="-1" role="dialog" aria-labelledby="gdprModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="gdprModalLabel">3rd Ranger Battalion Privacy Policy</h5>
                <button type="button" class="close" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p><strong>GDPR1: Notice and Information</strong></p>
                <p>Upon signing up to this website, users' personal information may be stored, such as name,
                     email,and phone number aswell as events attending.</p>

                <p><strong>GDPR2: Justification For Data Collection</strong></p>
                <p>We collect personal information to provide users with access to our website's features and
                    services. This information is also used to help improve services provided to you.</p>

                <p><strong>GDPR3: How Data Will Be Processed</strong></p>
                <p>User data will be processed securely and used solely for the purposes of access to our services
                    and features. We implement encryption and access controls to protect user data.</p>

                <p><strong>GDPR4: How Long Data Will Be Retained</strong></p>
                <p>User data will be retained for the duration of the user's account activity. Users can request data
                    deletion, and inactive accounts will be deleted after a specified period.</p>

                <p><strong>GDPR5: Who Can Be Contacted to Have Data Removed or Produced</strong></p>
                <p>Users can contact our support team at 2103490@uad.ac.uk to request data removal or access to
                    their stored information.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-events" onclick="denyAction()">DENY</button>
                <button type="button" class="btn btn-events" onclick="acceptAction()">ACCEPT</button>
            </div>
        </div>
    </div>
</div>



    <!-- Latest compiled Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>

</html>