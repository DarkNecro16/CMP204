<?php
session_start();
include_once "includes/connectionString.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    // Get user input from the registration form and trim whitespaces also remove any special chars to prevent CS scripting and SQLi
    $firstName = trim($_POST["firstName"]);
    $surname = trim($_POST["surname"]);
    $email = trim($_POST["email"]);
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);
    $confirmPassword = trim($_POST["confirmPassword"]); // Add this line

    // Validate and sanitize user inputs
    $firstName = htmlspecialchars($firstName, ENT_QUOTES, 'UTF-8');
    $surname = htmlspecialchars($surname, ENT_QUOTES, 'UTF-8');
    $email = filter_var($email, FILTER_VALIDATE_EMAIL);
    $username = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');

    if (!ctype_alpha($firstName) || !ctype_alpha($surname)) 
    {
        echo "Invalid first name or last name. Please enter a valid name with only letters.";
       
        header("Location: register.php");
        exit(); 
    }

    // Validate password
    if (strlen($password) < 10 || !preg_match("/[A-Z]/", $password) || !preg_match("/[^a-zA-Z0-9]/", $password)) 
    {
        echo "Invalid password! It must be at least 10 characters long, contain one uppercase letter, and one special character.";
        header("Location: register.php");
        exit();
    }

    // Validate if passwords match
    if ($password !== $confirmPassword) 
    {
        echo "Passwords do not match.";
        header("Location: register.php");
        exit();
    }

    if (!$email) 
    {
        // Handle invalid email
        echo "Invalid email address,cmon now!!";
        header("Location: register.php");
        exit();
    }

 
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // SQL statement to insert user data into the users table using prepared statements 
    $insertSQL = "INSERT INTO users (first_name, surname, email, username, password) 
                  VALUES (?, ?, ?, ?, ?)";

    // Prepare the statement
    $stmt = $conn->prepare($insertSQL);

    // Bind parameters with a 's' for each variable type string
    $stmt->bind_param("sssss", $firstName, $surname, $email, $username, $hashedPassword);

    if ($stmt->execute()) 
    {
        // Set session variables tying the user to account the user_id will be used to keep track of events_attended  for each user 
        $_SESSION['username'] = $username;
        $_SESSION['user_id'] = $stmt->insert_id; 

        // Redirect to the user profile page after successful registration
        header("Location: userProfile.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
