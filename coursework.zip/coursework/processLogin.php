<?php
session_start();
include_once "includes/connectionString.php";

// retrieves information submitted by the form HTML spec chars is used to prevent SQLi by converting special chars to HTML
//removes whitespace "trim" and special characters turn to html to prevent CS scripting and SQLi
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    $username = trim(htmlspecialchars($_POST["username"]));
    $password = trim(htmlspecialchars($_POST["password"]));

    // Use prepared statement with parameters to make a query to DB
    $sql = "SELECT id, password FROM users WHERE username = ?";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("s", $username);

    $stmt->execute();

    $result = $stmt->get_result();

    // if the user is found It will proceed to verify the password
    if ($result->num_rows > 0) 
    {
        $row = $result->fetch_assoc();

        $hashedPassword = $row["password"];

        // it will compare the user's password with the stored hashed password
        if (password_verify($password, $hashedPassword)) 
        {
            $_SESSION["username"] = $username;
            $_SESSION["user_id"] = $row["id"]; // Store the user_id in the session
            header("Location: userProfile.php");
            exit();
        } else 
        {
            header("Location: login.php?error=invalid");
            exit();
        }
    } else 
    {
        header("Location: login.php?error=userorpassnotfound");
        exit();
    }

    $stmt->close();
}

$conn->close();

?>
