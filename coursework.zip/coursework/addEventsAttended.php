<?php
session_start();

header('Content-Type: application/json'); 

include_once "includes/connectionString.php";

$response = array(); 

// the use of prepared statements here and sanitisation with HTMLSpecchars to prevent SQLi

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    $eventName = htmlspecialchars($_POST["eventName"]);

    // Uses prepared statements to ensure the event is not being attended
    $checkQuery = "SELECT * FROM attended_events WHERE event_name = ? AND user_id = ?";
    $check = $conn->prepare($checkQuery);
    $check->bind_param("si", $eventName, $_SESSION['user_id']);
    $check->execute();
    $checkResult = $check->get_result();

    if ($checkResult->num_rows == 0) 
    {
        // If it's not, insert into attended_events, and the attendance status will be set to 'yes' by default
        $insertQuery = "INSERT INTO attended_events (event_name, attendance_status, user_id) VALUES (?, 'yes', ?)";
        $insertStatement = $conn->prepare($insertQuery);
        $insertStatement->bind_param("si", $eventName, $_SESSION['user_id']);

        // Error handling
        if ($insertStatement->execute()) 
        {
            $response['status'] = 'success';
            $response['message'] = 'Event attended successfully.';
            
            // Check if the context is userProfile
            if ($_POST['context'] === 'userProfile') 
            {
                $response['redirect'] = 'userProfile.php';
            }
        } 

        // Close the prepared statement for insert
        $insertStatement->close();
    } else 
    {
        // Event is already attended
        $response['status'] = 'error';
        $response['message'] = 'Event is already attended.';
    }

    $check->close();
    $conn->close();
}

echo json_encode($response);

?>
