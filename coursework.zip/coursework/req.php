<!doctype html>

<html lang="en">
<head>
	<meta charset="utf-8">
	<title>CMP204 Unit Two Coursework Template</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="javascript/script.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg topnav">
    <div class="container-fluid">
        <?php include_once "includes/links.php" ?>
    </div>
</nav>

    
    <h1>CMP204 Requirements Page - Unit 2 Assessment</h1>
    
    <p>If you have not met a requirement, do not delete it from the table.</p>

        <table id="reqTable">
        <thead>
            <tr>
            <th class="reqCol">Requirement</th>
            <th class="metCol">How did you meet this requirement?</th>
            <th class="fileCol">File name(s), line no.</th>
            </tr>
        </thead>

        <tbody>
            <tr>
            <td>HTML5, CSS, JavaScript has been contained within separate files.</td>
            <td>yes all files have been kept seperate</td>
            <td> All</td>
            </tr>

            <tr>
            <td>Use of the Bootstrap framework providing a responsive layout.</td>
            <td>I used Bootstrap all throughout my application to maintain a uniform layout that has the "mobile first" methadology</td>
            <td>ALL</td>
            </tr>

            <tr>
            <td>Use of JavaScript to manipulate the DOM based on an event.</td>
            <td>I have a few situations when i have added event listeners throughout my application as you will see when browsing. DOM manipulation happens when there are a number of buttons clicked to show playerStats or dsplay Current Chanpionship
                Table. For the purposes of this requirment please take a look at the following lines. it demonstrates a mouseover function that changes the link items in the Nav bar. this is DOM Manipulation based on an event when the 
                mouseover happens it increases the size of text aswell as giving it a white shadow, and then returns to normal on mouseout 
            </td>
            <td>JS file lines 5-25</td>
            </tr>            
            
            <tr>
            <td>Use of jQuery in conjunction with the DOM.</td>
            <td>Again< i Have used Jquery throughout my application for example in my RecentResults, but for the purposes of this requirment please look at the Countdownclock on my upcomingEvents page this countdowns to the next upcoming event, it uses $ to select elements by there ID's and updates based 
                on the countdown calculations, this continues to run after the DOM has been fully loaded.</td>
            <td>JS 229-265 and upcomingEvents 42-52</td>
            </tr>

            <tr>
            <td>Use of AJAX (pure JavaScript i.e. without the use of a library).</td>
            <td>i performed an ajax request to pull in player statistics from a seperate txt file on the server playerStats.txt this is done by a listener pulling in the information via a XMLHTTP request.
            the updateGameInfo function takes the targetId and an array of player information, extracts the player's information based on the targetId, and updates the HTML  of the corresponding target 
             it then generates an HTML table with player details such as name, role, skills, level, wins, losses, and quote.
            </td>
            <td>JS 46-133, collapseable box in teamMembers.php to show data</td>
            </tr>

            <tr>
            <td>Use of the jQuery AJAX function.</td>
            <td> Have used this a couple of times throughout my application. To attend events on lines 274-350 there are two seperate instances here as there is 2 places on my app you can attend events on my upcoming events page
                and also my userprofile. but for the purposes of this requirment please take a look at my lague standings table. i set up a listener ad checks if the table is or is not visible, it then makes an ajax XML request to 
                pull information in from a file on the server LeagueStandings.xml and changes and displays it into an HTML format. 
            </td>
            <td>JS 138-221, button and container 119-125 in index.html</td>
            </tr>

            <tr>
            <td>User login functionality (PHP/MySQL).</td>
            <td>the application has full User login functionality.</td>
            <td>login.php - all and loginProcess - all</td>
            </tr>

            <tr>
            <td>Ability to select (SELECT), add (INSERT), edit (UPDATE) and delete (DELETE) information from a database (PHP/MySQL).</td>
            <td>(SELECT) is performed tweice in my application, addEventsAttended.php and processLogin. the addevents needs to check the current attended_events table as to ensure the user is not already attending the event
                and in processLogin.php t querys the DB to check for a user.

                (INSERT) is used when adding events ad creating a new user by inserting into the appropriate DB table addEventsAttended.php and processRegistration.php retrospectivly.

                (UPDATE) is used when editing the event attendance status. upon attending an event the status is set to yes by default but on the userProfile page the user can ammend this to no. this is on editEventsAttended.php
                
                (DELETE) is used to delete an attended event from the DB via the userProfile page. please see deleteEventAttended.php
            </td>
            <td> please see all lines in addEventsAttended.php, processLogin.php, editEventsAttended.php and deleteEventsAttended.php</td>
            </tr>

            <tr>
            <td>Inclusion of GDPR.</td>
            <td> i have included GDPR information at the bottom of every page in the form of a footer include. also when you go to the register page a pop up appears for acceptance or to be denied. its made clear 
                however that procession to create an account is acceptance of these conditions.
            </td>
            <td>see includes/footer.php and registration.php lines 75-112 and JS 385-406</td>
            </tr>

            <tr>
            <td>SQL queries written as prepared statements.</td>
            <td>Any time there are requests or input sent to the DB i have used Prepared statements (prepare,bind,execute) this is to protect against SQL injection aswell as to promote efficiency i have used them in all of the
                processing pages addEventsAttended.php, editEventsAttended.php, deleteEventsAttended.php, processLogin.php, processRegistration.php </td>
            <td>Please see all as i have used multiple times over some of these Files </td>
            </tr>

            <tr>
            <td>Passwords should be salted and hashed.</td>
            <td>passwords are hashed using the password_hash function in registrationProcess.php this function hashes the password using BCRYPT and salts the password by default</td>
            <td>lines 52 processRegistration.php</td>
            </tr>

            <tr>
            <td>User input should be sanitised.</td>
            <td>i have sanatized all requests made to and from the server, even where user input is not required. i just feel this is best practice and can only benefit security so i have used HTMLspecialchars that converts special characters to HTML
                this prevents SQLi and Cross site scripting. i have used these in my processLogin.php and processRegistration.php also, aswell as trim() to delete any white spaces on userinput awell as filterVar for email validation
                please note i have used additonal security sch as preg_match function to ensure passwords conform with a certain level of robustness. and ctype-alpha to ensure first and last names only contain letters. 
            </td>
            <td>
                used throughout but please see all lines in processegistration.php and processLogin.php primarly 
            </td>
            </tr>
        </tbody>



        </table>



    <!-- Latest compiled Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>